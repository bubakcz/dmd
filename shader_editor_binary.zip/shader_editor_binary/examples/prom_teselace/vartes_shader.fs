#version 400
out vec4 FragColor;
in vec3 teNormal;
in vec2 teTexcoord;
uniform sampler2D tesmap;     
uniform vec3 LightPosition;
uniform vec3 DiffuseMaterial;
uniform vec3 AmbientMaterial;
void main(){
    vec3 N = normalize(teNormal);
    vec3 L = LightPosition;
    float df = abs(dot(N, L));
    vec3 color = AmbientMaterial + df * texture(tesmap, teTexcoord).rgb;//DiffuseMaterial;
    FragColor = vec4(color, 1.0);
}
