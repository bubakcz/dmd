#version 400
out vec4 FragColor;
in vec3 teNormal;
in vec2 teTexcoord;     
in vec3 teLightVec;
in vec3 teEyeVec;
in vec3 teHalfVec;
uniform sampler2D diffuse_map;
uniform sampler2D normal_map;          
uniform vec3 LightPosition;
uniform vec3 DiffuseMaterial;
//uniform vec3 AmbientMaterial;
void main(){
    vec3 normal = 2.0 * texture2D (normal_map, teTexcoord).rgb - 1.0;
    normal = normalize(normal);   
		float lamberFactor= max (dot (teLightVec, normal), 0.0) ;
		    
    vec3 color = /*AmbientMaterial +*/ lamberFactor * texture(diffuse_map, teTexcoord).rgb;//texture(tesmap, teTexcoord).rgb;//DiffuseMaterial;
    FragColor = vec4(color, 1.0);
}
