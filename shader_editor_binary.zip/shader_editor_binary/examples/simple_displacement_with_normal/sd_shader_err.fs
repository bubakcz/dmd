#version 400
out vec4 FragColor;
in vec3 teNormal;
in vec2 teTexcoord;
in vec3 teTangent;
in vec3 teBitangent;
in vec3 teLightVec;
in vec3 teEyeVec;
in vec3 teHalfVec;
uniform sampler2D dispmap;
uniform sampler2D normmap;        
uniform vec3 LightPosition;
uniform vec3 DiffuseMaterial;
uniform vec3 AmbientMaterial;
void main(){
	FragColor = vec4(texture2D (normmap, teTexcoord).rgb,1.0);		  
}
