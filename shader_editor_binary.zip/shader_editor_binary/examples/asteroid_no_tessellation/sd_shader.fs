#version 400
out vec4 FragColor;
//in vec3 vNormal;
in vec2 vTexCoord;
//in vec3 teTangent;
//in vec3 teBitangent;
in vec3 vLightVec;
in vec3 vEyeVec;
in vec3 vHalfVec;
//uniform sampler2D diffuse_texture;
uniform sampler2D normal_texture;        
uniform vec3 LightPosition;
uniform vec3 DiffuseMaterial;
uniform vec3 AmbientMaterial;
void main(){
    vec3 normal = 2.0 * texture2D (normal_texture, vTexCoord).rgb - 1.0;
    normal = normalize(normal);   
    
		float lamberFactor= max (dot (vLightVec, normal), 0.0) ;
		vec4 diffMaterial = vec4(0.0,0.0,0.0,0.0);
		vec4 diffUseLight  = vec4(0.0,0.0,0.0,0.0);
		
		vec4 specularMaterial ;
		vec4 specularLight ;
		float shininess ;
		
		vec4 ambientLight = vec4(AmbientMaterial,1.0);//(0.1,0.1,0.1);	
		
	if (lamberFactor > 0.0)
	{
		FragColor = vec4(lamberFactor * DiffuseMaterial,1.0);
	/*
		diffMaterial = vec4(DiffuseMaterial,1.0);//texture2D (diffuseTexture, gl_TexCoord[0].st);
		diffUseLight  = vec4(0.6,0.6,0.6,1.0);//gl_LightSource[0].diffuse;
		
		// In doom3, specular value comes from a texture 
		specularMaterial =  vec4(1.0)  ;
		specularLight = vec4(0.0);//gl_LightSource[0].specular;
		shininess = pow (max (dot (teHalfVec, normal), 0.0), 2.0)  ;
		 
		FragColor =	diffMaterial * diffUseLight * lamberFactor ;
		FragColor +=	specularMaterial * specularLight * shininess ;	*/			
	
	}		
	
	FragColor +=ambientLight;
			   
	 
}
